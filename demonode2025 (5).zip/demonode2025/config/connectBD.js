import mysql from "mysql2";

export const db = mysql.createConnection({
  host: "localhost", 
  user: "root",      
  password: "",      
  database: "demonode2025", 
});

db.connect((err) => {
  if (err) {
    console.error(" Lỗi kết nối MySQL:", err);
    return;
  }
  console.log(" Kết nối MySQL thành công!");
});
