import mysql from 'mysql2';

const connection = mysql.createConnection({
    host: 'localhost', // Hoặc IP của database
    user: 'root', // Thay bằng user của bạn
    password: '', // Thay bằng password của bạn
    database: 'demonode2025' // Tên database
});

connection.connect(err => {
    if (err) {
        console.error('Lỗi kết nối MySQL:', err);
    } else {
        console.log('Kết nối MySQL thành công!');
    }
});

export default connection;
