import { Sequelize } from "sequelize";

const sequelize = new Sequelize("demonode2025", "root", "", {
  host: "localhost",
  dialect: "mysql",
  logging: false, // Tắt log SQL
  timezone: "+07:00",
});

sequelize
  .authenticate()
  .then(() => console.log("✅ Kết nối CSDL thành công!"))
  .catch((err) => console.error("❌ Lỗi kết nối CSDL:", err));

export default sequelize;
