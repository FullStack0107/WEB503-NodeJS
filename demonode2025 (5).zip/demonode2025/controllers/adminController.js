import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Admin from "../models/admin.js"; // Model của Admin

export const showLoginForm = (req, res) => {
    res.render("admin/login"); // Hiển thị trang đăng nhập (EJS hoặc HTML)
};

export const login = async (req, res) => {
    const { username, password } = req.body;
    
    try {
        const admin = await Admin.findOne({ where: { username } });
        if (!admin) {
            return res.status(401).json({ message: "Sai tài khoản hoặc mật khẩu" });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: "Sai tài khoản hoặc mật khẩu" });
        }

        // Tạo token
        const token = jwt.sign({ id: admin.id, username: admin.username }, "secretKey", { expiresIn: "1h" });

        res.cookie("adminToken", token, { httpOnly: true }); // Lưu token vào cookie
        res.redirect("/admin/dashboard"); // Chuyển hướng đến trang admin
    } catch (error) {
        res.status(500).json({ message: "Lỗi server", error });
    }
};

export const dashboard = (req, res) => {
    res.send("Chào mừng đến trang Admin");
};

export default { showLoginForm, login, dashboard };
