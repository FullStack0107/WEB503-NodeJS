import { db } from "../config/connectDB.js";
import bcrypt from "bcrypt";

class AuthController {
  static login(req, res) {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: "Vui lòng nhập đầy đủ thông tin!" });
    }

    // Tìm user trong database
    const sql = "SELECT * FROM users WHERE username = ?";
    db.query(sql, [username], (err, results) => {
      if (err) {
        console.error("Lỗi MySQL:", err);
        return res.status(500).json({ message: "Lỗi hệ thống!" });
      }

      if (results.length === 0) {
        return res.status(401).json({ message: "Tài khoản không tồn tại!" });
      }

      const user = results[0];

      // So sánh mật khẩu đã mã hóa
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error("Lỗi bcrypt:", err);
          return res.status(500).json({ message: "Lỗi hệ thống!" });
        }

        if (!isMatch) {
          return res.status(401).json({ message: "Mật khẩu không đúng!" });
        }

        res.json({ message: "Đăng nhập thành công!", user });
      });
    });
  }
}

export default AuthController;
