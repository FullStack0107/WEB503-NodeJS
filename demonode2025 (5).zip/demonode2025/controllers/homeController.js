import { db } from "../../demonode2025/config/connectBD.js";
class HomeController {
  static index(req, res) {
    let users = [
      {
        id: 1,
        name: "Nguyen van AA",
        email: "abc@gmail.com",
      },
      {
        id: 2,
        name: "Nguyen van B",
        email: "abcd@gmail.com",
      },
      {
        id: 3,
        name: "Nguyen van D",
        email: "abcf@gmail.com",
      },
    ];
    res.render("home/index", { users });

  }


    static listProduct(req, res) {
      let q = req.query.q || "";
  
      let sql = `SELECT * FROM products WHERE name LIKE '%${q}%'`;
  
      db.query(sql, (err, data) => {
        if (err) {
          console.error("Lỗi truy vấn danh sách sản phẩm:", err);
          return res.status(500).send("Lỗi server");
        }
        res.render("products", { products: data });
      });
    }
  
    static productDetail(req, res) {
      let productId = req.params.id;
  
      let sql = `SELECT * FROM products WHERE id = ?`;
  
      db.query(sql, [productId], (err, data) => {
        if (err) {
          console.error("Lỗi truy vấn chi tiết sản phẩm:", err);
          return res.status(500).send("Lỗi server");
        }
        if (data.length === 0) {
          return res.status(404).send("Không tìm thấy sản phẩm!");
        }
        res.render("productDetail", { product: data[0] });
      });
    }
  }
  

export default HomeController;
