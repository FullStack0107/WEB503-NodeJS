import Product from "../models/product.js";
import { Op } from "sequelize";

export const getAllProducts = async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};


export const createProduct = async (req, res) => {
  try {
    const { name, description, image, price } = req.body;
    const newProduct = await Product.create({ name, description, image, price });
    res.status(201).json(newProduct);
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};


export const updateProduct = async (req, res) => {
  try {
    const { name, description, image, price } = req.body;
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ message: "Không tìm thấy sản phẩm" });

    await product.update({ name, description, image, price });
    res.json({ message: "Cập nhật thành công", product });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};

export const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);
    if (!product) return res.status(404).json({ message: "Không tìm thấy sản phẩm" });

    await product.destroy();
    res.json({ message: "Xóa thành công" });
  } catch (error) {
    res.status(500).json({ message: "Lỗi server", error });
  }
};


export default class ProductsController {
  static async index(req, res) {
    try {

      let limit = 2;
      let name = req.query.name;
   
      let page = parseInt(req.query.page);
      page = page ? page: 1;
      //2
      let offset = limit * (page -1);

      name = name ? name : "";

      let products = await Product.findAll({
        limit,
        offset,
        where: {
          name: { [Op.like]: `%${name}%`},
        },
      });
      res.status(200).json({ data: products });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async show(req, res) {
    try {
      let id = req.params.id;
      let product = await Product.findByPk(id);
      res.status(200).json({ data: product });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async create(req, res) {
    try {
      let { name, description, image, price } = req.body;
      let product = await Product.create({ name, description, image, price });
      res.status(200).json({ message: "Tạo mới thành công!!", data: product });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
   static async update(req, res) {
    try {
    let id = req.params.id;
    let params = req.body;
    let product = await Product.update(params, {
      where: {
        id,
      },
    });
    res.status(200).json({message: "update thanh cong!!!", id});
   } catch (error) {
    res. status(500).json({error: error.message});
   }
}
static async destroy(req, res) {
  try {
    let id = req.params.id;
    let product = await Product.destroy({
      where: {
        id,
      },
    });
    res.status(200).json({ message: "xoa thanh cong!!!"});
  } catch (error) {
    res. status(500).json({ error: error.message});
  }
}
}