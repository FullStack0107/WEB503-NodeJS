import { db } from "../../demonode2025/config/connectBD.js";
import User from "../models/user.js";

class UserController {
  static async index(req, res) {
    let data = await User.getAll();
    res.render("users/index", { users: data });
  }

  static new(req, res) {
    res.render("users/formCreate");
  }

  static create(req, res) {
    const userParams = req.body;
    console.log(userParams);
    db.query("INSERT INTO user SET ?", userParams, function (err, data) {
      if (err) res.render("users/formCreate");
      res.redirect("/users");
    });
  }

  // Hiển thị form đăng nhập
  static showLoginForm(req, res) {
    res.render("users/login"); // Đảm bảo có file views/users/login.ejs
  }

  // Xử lý đăng nhập
  static async login(req, res) {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).send("Vui lòng nhập đầy đủ thông tin!");
    }

    db.query("SELECT * FROM user WHERE username = ?", [username], async (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Lỗi hệ thống");
      }

      if (results.length === 0) {
        return res.status(401).send("Tài khoản không tồn tại!");
      }

      const user = results[0];

      if (password === user.password) { // ⚠️ Nếu dùng bcrypt, cần thay bằng bcrypt.compare()
        return res.send("Đăng nhập thành công!");
      } else {
        return res.status(401).send("Sai mật khẩu!");
      }
    });
  }
}


export default UserController;
