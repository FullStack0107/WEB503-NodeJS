import jwt from "jsonwebtoken";

export const authenticateAdmin = (req, res, next) => {
    const token = req.cookies.adminToken;
    if (!token) {
        return res.redirect("/admin/login");
    }

    try {
        const decoded = jwt.verify(token, "secretKey");
        req.admin = decoded;
        next();
    } catch (error) {
        res.redirect("/admin/login");
    }
};
