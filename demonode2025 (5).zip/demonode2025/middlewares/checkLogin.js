import jwt from "jsonwebtoken";

export function checkLoginMiddware(req, res, next) {
  if (req.session?.user) next();
  else res.redirect("/login/form");
}

export function checkLoginAPIMiddware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Bạn cần đăng nhập!" });
  }

  const token = authHeader.split(" ")[1]; // Lấy token sau "Bearer "
  
  try {
    jwt.verify(token, "Nodejs");
    next();
  } catch (error) {
    return res.status(403).json({ message: "Token không hợp lệ!" });
  }
}
