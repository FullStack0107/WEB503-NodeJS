import { DataTypes } from "sequelize";
import sequelize from "../config/ormConnect.js";  // ✅ Đúng




const Product = sequelize.define(
  "Product",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    image: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    price: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 0,
      },
    },
    deletedAt: {
      type: DataTypes.DATE, // Cần để hỗ trợ xóa mềm
      allowNull: true,
    },
  },
  {
    timestamps: true, // Tự động tạo createdAt và updatedAt
    paranoid: true, // Xóa mềm, không xóa dữ liệu thật sự
    tableName: "products", // Tên bảng trong database
  }
);

export default Product;
