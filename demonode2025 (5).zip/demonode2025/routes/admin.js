import express from "express";
import AdminController from "../controllers/adminController.js";
import { authenticateAdmin } from "../middlewares/auth.js";
const adminRouter = express.Router();


adminRouter.get("/dashboard", authenticateAdmin, AdminController.dashboard);

adminRouter.get("/login", AdminController.showLoginForm); // Hiển thị form đăng nhập
adminRouter.post("/login", AdminController.login); // Xử lý đăng nhập
adminRouter.get("/dashboard", AdminController.dashboard); // Trang Admin (cần đăng nhập)




export default adminRouter;
