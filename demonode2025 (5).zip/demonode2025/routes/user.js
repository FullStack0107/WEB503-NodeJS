import express from "express";
import bcrypt from "bcryptjs";

import UserController from "../controllers/userController.js";
 

const userRouter = express.Router();


userRouter.get("/", UserController.index);
userRouter.get("/new", UserController.new);
userRouter.post("/create", UserController.create);
userRouter.get("/login", UserController.showLoginForm); // Hiển thị form đăng nhập
userRouter.post("/login", UserController.login); // Xử lý đăng nhập



export default userRouter;
